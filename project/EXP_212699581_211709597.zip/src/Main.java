import java.io.DataOutputStream;
import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        DataOutputStream out = new DataOutputStream(System.out);

        DynamicGraph graph = new DynamicGraph();
        GraphNode v1 = graph.insertNode(1);
        GraphNode v2 = graph.insertNode(2);
        GraphNode v3 = graph.insertNode(3);
        GraphNode v4 = graph.insertNode(4);
        GraphNode v5 = graph.insertNode(5);
        GraphNode v6 = graph.insertNode(6);
        GraphNode v7 = graph.insertNode(7);
        GraphNode v8 = graph.insertNode(8);

        graph.insertEdge(v1, v2);
        graph.insertEdge(v1, v3);
        graph.insertEdge(v2, v3);
        graph.insertEdge(v3, v4);
        graph.insertEdge(v3, v5);
        graph.insertEdge(v5, v4);
        graph.insertEdge(v5, v1);
        graph.insertEdge(v6, v2);
        graph.insertEdge(v6, v7);
        graph.insertEdge(v7, v1);
        graph.insertEdge(v7, v8);
        graph.insertEdge(v8, v5);
        graph.insertEdge(v8, v6);


        RootedTree treeBFS = graph.bfs(v1);

        treeBFS.printByLayer(out);
        out.writeBytes(System.lineSeparator());
        treeBFS.preorderPrint(out);
        out.writeBytes(System.lineSeparator());
        list<RootedTree> treeDFS = graph.dfs();

        for (node<RootedTree> treeNode = treeDFS.getHead(); treeNode != null; treeNode = treeNode.getNext()) {
            RootedTree tree = treeNode.getData();
            tree.printByLayer(out);
            out.writeBytes(System.lineSeparator());
            tree.preorderPrint(out);
            out.writeBytes(System.lineSeparator());
        }

        RootedTree scc = graph.scc();

        scc.printByLayer(out);
        out.writeBytes(System.lineSeparator());
        scc.preorderPrint(out);
        out.writeBytes(System.lineSeparator());

    }
}
