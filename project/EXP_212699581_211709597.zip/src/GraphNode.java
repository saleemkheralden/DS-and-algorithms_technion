public class GraphNode {

    private int key;
    private int outDegree, inDegree;
    private list<GraphEdge> outEdges, inEdges;
    private boolean deleted;

    private GraphNode pi;
    private int d, f;
    private Colors color;
    private GraphNode leftChild, rightSibling;

    private node<GraphNode> DynamicGraphNode;

    public GraphNode(int key) {
        this.key = key;
        this.outDegree = this.inDegree = 0;
        this.outEdges = new list<>();
        this.inEdges = new list<>();
        this.deleted = false;
        this.DynamicGraphNode = null;

        this.pi = null;
        this.leftChild = null;
        this.rightSibling = null;

        this.d = this.f = Integer.MIN_VALUE;
        this.color = Colors.WHITE;
    }

    // HW questions
    public int getOutDegree() {
        return this.outDegree;
    }

    public int getInDegree() {
        return this.inDegree;
    }

    public int getKey() {
        return this.key;
    }
    // end HW questions


    public GraphNode getRightSibling() {
        return rightSibling;
    }
    public GraphNode getLeftChild() {
        return leftChild;
    }
    public GraphNode getParent() {
        return pi;
    }
    public int getD() {
        return this.d;
    }
    public int getF() {
        return this.f;
    }
    public Colors getColor() {
        return color;
    }
    public list<GraphEdge> getOutEdges() {
        return outEdges;
    }
    public list<GraphEdge> getInEdges() {
        return inEdges;
    }
    public node<GraphNode> getDynamicGraphNode() {
        return DynamicGraphNode;
    }

    public void setRightSibling(GraphNode rightSibling) {
        this.rightSibling = rightSibling;
    }
    public void setLeftChild(GraphNode leftChild) {
        this.leftChild = leftChild;
    }
    public void setParent(GraphNode parent) {
        this.pi = parent;
    }
    public void setD(int d) {
        this.d = d;
    }
    public void setF(int f) {
        this.f = f;
    }
    public void setColor(Colors color) {
        this.color = color;
    }
    public void setDynamicGraphNode(node<GraphNode> dynamicGraphNode) {
        this.DynamicGraphNode = dynamicGraphNode;
    }

    public void insertOutEdge(GraphEdge edge) {
        this.outEdges.insertFirst(edge);
        this.outDegree++;
    }
    public void insertInEdge(GraphEdge edge) {
        this.inEdges.insertFirst(edge);
        this.inDegree++;
    }

    public void setOutDegree(int outDegree) {
        this.outDegree = outDegree;
    }
    public void setInDegree(int inDegree) {
        this.inDegree = inDegree;
    }

    public void delete() {
        if (this.outDegree + this.inDegree == 0)
            this.deleted = true;
    }
    public boolean isDeleted() {
        return this.deleted;
    }

}
