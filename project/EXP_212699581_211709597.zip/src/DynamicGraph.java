public class DynamicGraph {

    private list<GraphNode> nodeList, sccList;
    private list<GraphEdge> edgeList;
    private boolean isTranspose;

    public DynamicGraph() {
         this.nodeList = new list<>();
         this.edgeList = new list<>();
         this.sccList = new list<>();
         this.isTranspose = false;
    }

    public GraphNode insertNode(int nodeKey) {
        GraphNode node = new GraphNode(nodeKey);
        this.nodeList.insertFirst(node);
        node.setDynamicGraphNode(this.nodeList.getHead());
        return node;
    }
    public GraphEdge insertEdge(GraphNode from, GraphNode to) {
        GraphEdge edge = new GraphEdge(from, to);
        this.edgeList.insertFirst(edge);
        edge.setDynamicGraphEdge(this.edgeList.getHead());
        return edge;
    }

    public void deleteNode(GraphNode node) {
        node.delete();
        if (node.getInDegree() + node.getOutDegree() == 0)
            this.nodeList.delete(node.getDynamicGraphNode());
    }
    public void deleteEdge(GraphEdge edge) {
        edge.delete();
        this.edgeList.delete(edge.getDynamicGraphEdge());
    }

    public list<GraphNode> getNodeList() {
        return nodeList;
    }
    public list<GraphEdge> getEdgeList() {
        return edgeList;
    }

    public void setNodeList(list<GraphNode> nodeList) {
        this.nodeList = nodeList;
    }
    public void setEdgeList(list<GraphEdge> edgeList) {
        this.edgeList = edgeList;
    }

    private void bfs_init(GraphNode s, queue<GraphNode> Q) {

        for (node<GraphNode> node = this.nodeList.getHead(); node != null; node = node.getNext()) {
            GraphNode v = node.getData();

            if (v.getKey() == s.getKey() || v.isDeleted())
                continue;

            v.setColor(Colors.WHITE);
            v.setD(Integer.MIN_VALUE);
            v.setParent(null);
            v.setLeftChild(null);
            v.setRightSibling(null);
        }

        s.setD(0);
        s.setColor(Colors.GRAY);
        s.setParent(null);
        s.setLeftChild(null);
        s.setRightSibling(null);

        Q.Enqueue(s);
    }

    public RootedTree bfs(GraphNode source) {
        queue<GraphNode> Q = new queue<>();
        bfs_init(source, Q);

        RootedTree tree = new RootedTree(source);


        while (!Q.isEmpty()) {
            GraphNode u = Q.Dequeue();

            boolean firstChild = true;
            GraphNode prevV = null;

            for (node<GraphEdge> edgenode = u.getOutEdges().getHead(); edgenode != null; edgenode = edgenode.getNext()) {
                if (edgenode.getData().isDeleted())
                    continue;

                GraphNode v = edgenode.getData().getTo();

                if (v.getColor() == Colors.WHITE) {
                    v.setColor(Colors.GRAY);
                    v.setD(u.getD() + 1);
                    v.setParent(u);

                    if (firstChild) {
                        u.setLeftChild(v);
                        firstChild = false;
                    }
                    else
                        prevV.setRightSibling(v);
                    prevV = v;

                    Q.Enqueue(v);
                }
            }

            u.setColor(Colors.BLACK);
        }

        return tree;
    }

    public int dfs_visit(GraphNode u, int time) {
        time = time + 1;
        u.setD(time);
        u.setColor(Colors.GRAY);

        boolean firstChild = true;
        GraphNode prevV = null;

        for (node<GraphEdge> edgenode = this.isTranspose ? u.getInEdges().getHead() : u.getOutEdges().getHead();
             edgenode != null; edgenode = edgenode.getNext()) {

            if (edgenode.getData().isDeleted())
                continue;

            GraphNode v = this.isTranspose ? edgenode.getData().getFrom() : edgenode.getData().getTo();

            if (v.getColor() == Colors.WHITE) {
                v.setParent(u);

                if (firstChild) {
                    u.setLeftChild(v);
                    firstChild = false;
                }
                else
                    prevV.setRightSibling(v);
                prevV = v;

                time = dfs_visit(v, time);
            }
        }

        u.setColor(Colors.BLACK);
        time = time + 1;
        u.setF(time);

        this.sccList.insertFirst(u);

        return time;
    }

    public list<RootedTree> dfs() {
        for (node<GraphNode> node = this.nodeList.getHead(); node != null; node = node.getNext()) {
            GraphNode u = node.getData();
            u.setColor(Colors.WHITE);
            u.setD(Integer.MIN_VALUE);
            u.setF(Integer.MIN_VALUE);
            u.setParent(null);
            u.setRightSibling(null);
            u.setLeftChild(null);
        }

        int time = 0;

        list<RootedTree> forest = new list<>();
        list<GraphNode> dfsList = this.isTranspose ? this.sccList : this.nodeList;


        for (node<GraphNode> node = dfsList.getHead(); node != null; node = node.getNext()) {
            GraphNode u = node.getData();

            if (u.isDeleted())
                continue;

            if (u.getColor() == Colors.WHITE) {

                forest.insert(new RootedTree(u));

                time = dfs_visit(u, time);
            }
        }

        return forest;
    }

    private DynamicGraph transpose() {
        DynamicGraph transpose = new DynamicGraph();
        transpose.isTranspose = true;
        transpose.sccList = this.sccList;
        transpose.nodeList = this.nodeList;
        transpose.edgeList = this.edgeList;

        return transpose;
    }

    public RootedTree scc() {
        this.dfs();
        DynamicGraph transpose = this.transpose();
        list<RootedTree> forest = transpose.dfs();

        GraphNode root = new GraphNode(0);
        root.setLeftChild(forest.getHead().getData().getRoot());
        GraphNode prevV = root.getLeftChild();

        for (node<RootedTree> treeNode = forest.getHead().getNext();
             treeNode != null; treeNode = treeNode.getNext()) {
            GraphNode v = treeNode.getData().getRoot();
            prevV.setRightSibling(v);
            prevV = v;
        }

        return new RootedTree(root);
    }
}












