public class list<T> {

    private node<T> head, last;

    public list() {
        this.head = this.last = null;
    }
    public list(T data) {
        this.head = this.last = new node<>(data);
    }

    public void insert(T data) {
        if (this.head == null) {
            this.head = this.last = new node<>(data);
            return;
        }

        this.last.setNext(new node<>(data));
        this.last.getNext().setPrevious(this.last);
        this.last = this.last.getNext();
    }

    public void insertFirst(T data) {
        if (this.head == null) {
            this.insert(data);
            return;
        }

        this.head.setPrevious(new node<>(data));
        this.head.getPrevious().setNext(this.head);
        this.head = this.head.getPrevious();

    }

    public T remove() {
        node<T> node = this.last;
        this.last = this.last.getPrevious();
        if (this.last == null)
            this.head = null;
        else {
            this.last.setNext(null);
            node.setPrevious(null);
        }

        return node.getData();
    }

    public void delete(node<T> node) {

        if (this.head == node && this.head == this.last) {
            this.head = this.last = null;
            return;
        }

        if (this.head == node) {
            this.head = this.head.getNext();
            this.head.setPrevious(null);
            return;
        }

        if (this.last == node) {
            this.last = this.last.getPrevious();
            this.last.setNext(null);
            return;
        }

        node.getNext().setPrevious(node.getPrevious());
        node.getPrevious().setNext(node.getNext());
    }

    public boolean isEmpty() {
        return this.head == null;
    }

    public node<T> getHead() {
        return head;
    }
    public node<T> getLast() {
        return last;
    }

    public void setHead(node<T> head) {
        this.head = head;
    }
    public void setLast(node<T> last) {
        this.last = last;
    }
}
