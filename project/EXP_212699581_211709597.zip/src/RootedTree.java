import java.io.DataOutputStream;
import java.io.IOException;

public class RootedTree {

    private GraphNode root;
    private StringBuilder[] layers;

    public RootedTree() {
        this.root = null;
    }

    public RootedTree(GraphNode root) {
        this.root = root;
    }

    public GraphNode getRoot() {
        return root;
    }
    public void setRoot(GraphNode root) {
        this.root = root;
    }

    private void updateDepth(GraphNode node, int d) {
        while (node != null) {
            node.setD(d);
            updateDepth(node.getLeftChild(), d + 1);
            node = node.getRightSibling();
        }
    }
    private int getHeight(GraphNode root) {
        if (root == null)
            return -1;

        int max_height = 0;
        for (; root != null; root = root.getRightSibling()) {
            int height = getHeight(root.getLeftChild()) + 1;
            if (height > max_height)
                max_height = height;
        }

        return max_height;
    }
    private void scanAndUpdate(GraphNode v) {
        if (v == null)
            return;

        layers[v.getD()].append(v.getKey()).append(",");

        scanAndUpdate(v.getLeftChild());
        scanAndUpdate(v.getRightSibling());
    }


    public void printByLayer(DataOutputStream out) throws IOException {
        StringBuilder st = new StringBuilder();

        this.updateDepth(this.root, 0);

        this.layers = new StringBuilder[this.getHeight(this.root) + 1];

        for (int i = 0; i < this.layers.length; i++)
            this.layers[i] = new StringBuilder();

        this.scanAndUpdate(this.root);

        for (int i = 0; i < this.layers.length; i++) {
            if (i == this.layers.length - 1) {
                st.append(this.layers[i].deleteCharAt(this.layers[i].length() - 1));
                continue;
            }
            st.append(this.layers[i].deleteCharAt(this.layers[i].length() - 1)).append('\n');
        }
        out.writeBytes(st.toString());
    }

    public void preorderPrint(DataOutputStream out) throws IOException {
        final int PARENT_SIBLING = 1, CHILD = 0;
        StringBuilder st = new StringBuilder();

        int from = PARENT_SIBLING;
        GraphNode x = this.root;

        while (x != null) {
            if (from == PARENT_SIBLING) {
                st.append(x.getKey()).append(",");
                if (x.getLeftChild() != null)
                    x = x.getLeftChild();
                else if (x.getRightSibling() != null)
                    x = x.getRightSibling();
                else {
                    from = CHILD;
                    x = x.getParent();
                }
            }
            else {
                if (x.getRightSibling() != null) {
                    from = PARENT_SIBLING;
                    x = x.getRightSibling();
                }
                else
                    x = x.getParent();
            }
        }

        st.deleteCharAt(st.length() - 1);
        out.writeBytes(st.toString());
    }

}
