public enum Colors {
    WHITE("White"),
    GRAY("Gray"),
    BLACK("Black");

    public final String color;
    Colors(String color) {
        this.color = color;
    }
}
