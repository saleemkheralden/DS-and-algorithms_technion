public class node<T> {
    private T data;
    private node<T> next, previous;

    public node() {
        this.data = null;
        this.next = null;
        this.previous = null;
    }
    public node(T data) {
        this.data = data;
        this.next = null;
        this.previous = null;
    }
    public node(T data, node<T> next) {
        this.data = data;
        this.next = next;
        this.previous = null;
    }
    public node(T data, node<T> next, node<T> previous) {
        this.data = data;
        this.next = next;
        this.previous = previous;
    }

    public void setNext(node<T> next) {
        this.next = next;
    }
    public void setPrevious(node<T> previous) {
        this.previous = previous;
    }
    public void setData(T data) {
        this.data = data;
    }

    public node<T> getNext() {
        return next;
    }
    public node<T> getPrevious() {
        return previous;
    }
    public T getData() {
        return data;
    }


}
