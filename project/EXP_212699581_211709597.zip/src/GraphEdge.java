public class GraphEdge {

    private GraphNode from, to;
    private boolean deleted;
    private node<GraphEdge> DynamicGraphEdge;

    public GraphEdge(GraphNode from, GraphNode to) {
        this.from = from;
        this.to = to;
        this.deleted = false;
        this.DynamicGraphEdge = null;
        from.insertOutEdge(this);
        to.insertInEdge(this);
    }

    public GraphNode getTo() {
        return to;
    }
    public GraphNode getFrom() {
        return from;
    }
    public node<GraphEdge> getDynamicGraphEdge() {
        return DynamicGraphEdge;
    }

    public void setTo(GraphNode to) {
        this.to = to;
    }
    public void setFrom(GraphNode from) {
        this.from = from;
    }
    public void setDynamicGraphEdge(node<GraphEdge> dynamicGraphEdge) {
        this.DynamicGraphEdge = dynamicGraphEdge;
    }

    public void delete() {
        this.deleted = true;
        this.from.setOutDegree(this.from.getOutDegree() - 1);
        this.to.setInDegree(this.to.getInDegree() - 1);
    }

    public boolean isDeleted() {
        return this.deleted;
    }

}
