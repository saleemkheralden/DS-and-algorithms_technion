public class queue<T> {
    private list<T> list;

    public queue() {
        this.list = new list<>();
    }

    public void Enqueue(T data) {
        list.insertFirst(data);
    }

    public T Dequeue() {
        return list.remove();
    }

    public boolean isEmpty() {
        return list.isEmpty();
    }


}
